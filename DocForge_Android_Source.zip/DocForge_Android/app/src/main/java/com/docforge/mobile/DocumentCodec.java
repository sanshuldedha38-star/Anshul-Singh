package com.docforge.mobile;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.text.Html;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/** No third-party runtime dependencies. Basic Office Open XML creation and editing. */
public final class DocumentCodec {
    private static final String W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    private static final String A = "http://schemas.openxmlformats.org/drawingml/2006/main";
    private static final String P = "http://schemas.openxmlformats.org/presentationml/2006/main";
    private static final String S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final int MAX_UNZIPPED = 48 * 1024 * 1024;
    private DocumentCodec() {}
    private static String ext(String name) { int i = name.lastIndexOf('.'); return i < 0 ? "" : name.substring(i).toLowerCase(Locale.ROOT); }
    private static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;"); }
    private static String text(byte[] bytes) { return new String(bytes, StandardCharsets.UTF_8); }
    private static byte[] utf8(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    private static Document xml(byte[] bytes) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch(Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch(Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch(Exception ignored) {}
        f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(new ByteArrayInputStream(bytes));
    }
    private static byte[] serialize(Document d) throws Exception {
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        t.transform(new DOMSource(d), new StreamResult(out));
        return out.toByteArray();
    }
    private static LinkedHashMap<String,byte[]> unzip(byte[] b) throws Exception {
        LinkedHashMap<String,byte[]> files = new LinkedHashMap<>();
        int total = 0;
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(b))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int count;
                while ((count = z.read(buf)) != -1) {
                    total += count;
                    if (total > MAX_UNZIPPED) throw new Exception("Document exceeds size limit");
                    o.write(buf, 0, count);
                }
                files.put(e.getName(), o.toByteArray());
            }
        }
        return files;
    }
    private static byte[] zip(Map<String,byte[]> m) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(out)) {
            for (Map.Entry<String,byte[]> e : m.entrySet()) {
                z.putNextEntry(new ZipEntry(e.getKey()));
                z.write(e.getValue()); z.closeEntry();
            }
        }
        return out.toByteArray();
    }
    private static String readStr(Map<String,byte[]> m, String key) { byte[] b = m.get(key); return b == null ? "" : text(b); }
    private static String nodeText(Node n, String ns, String tag) {
        StringBuilder sb = new StringBuilder();
        if (n instanceof Element) {
            NodeList texts = ((Element)n).getElementsByTagNameNS(ns, tag);
            for (int i=0; i<texts.getLength(); i++) sb.append(texts.item(i).getTextContent());
        }
        return sb.toString();
    }
    public static JSONObject decode(String filename, byte[] bytes) throws Exception {
        String extension = ext(filename);
        JSONObject result = new JSONObject().put("name", filename);
        switch (extension) {
            case ".docx": {
                Map<String,byte[]> z = unzip(bytes);
                if (!z.containsKey("word/document.xml")) throw new Exception("Invalid DOCX");
                Document d = xml(z.get("word/document.xml"));
                NodeList ps = d.getElementsByTagNameNS(W, "p");
                StringBuilder html = new StringBuilder();
                for (int i=0; i<ps.getLength(); i++) {
                    Element p = (Element)ps.item(i);
                    StringBuilder line = new StringBuilder();
                    NodeList runs = p.getElementsByTagNameNS(W, "r");
                    for (int j=0;j<runs.getLength();j++) {
                        Element r = (Element)runs.item(j);
                        String s = nodeText(r, W, "t");
                        if (r.getElementsByTagNameNS(W, "tab").getLength()>0) s += "\t";
                        if (r.getElementsByTagNameNS(W, "br").getLength()>0) s += "\n";
                        if (s.isEmpty()) continue;
                        Element properties = null;
                        NodeList props = r.getElementsByTagNameNS(W, "rPr");
                        if (props.getLength()>0) properties=(Element)props.item(0);
                        boolean bold = properties != null && properties.getElementsByTagNameNS(W,"b").getLength()>0;
                        boolean italic = properties != null && properties.getElementsByTagNameNS(W,"i").getLength()>0;
                        boolean underline = properties != null && properties.getElementsByTagNameNS(W,"u").getLength()>0;
                        if (bold) line.append("<b>"); if (italic) line.append("<i>"); if (underline) line.append("<u>");
                        line.append(esc(s).replace("\n", "<br>"));
                        if (underline) line.append("</u>"); if (italic) line.append("</i>"); if (bold) line.append("</b>");
                    }
                    html.append("<p>").append(line).append("</p>");
                }
                return result.put("kind", "document").put("html", html.toString())
                        .put("notice", "Basic DOCX text formatting supported; complex layouts, images and tracked changes may not survive saving. Use Save As.");
            }
            case ".xlsx": return result.put("kind", "sheet").put("sheets", readXlsx(bytes))
                    .put("notice", "Basic spreadsheet editing supported; advanced charts, macros and formatting are not preserved. Use Save As.");
            case ".pptx": return result.put("kind", "slides").put("slides", readSlides(bytes))
                    .put("notice", "Text changes can retain the original slides; adding or deleting slides may simplify the original layout.");
            case ".csv": return result.put("kind", "sheet").put("sheets", csvAsSheets(text(bytes)));
            case ".rtf": return result.put("kind", "text").put("text", rtfToText(new String(bytes, StandardCharsets.ISO_8859_1)))
                    .put("notice", "RTF is opened as plain text. Save As TXT to avoid overwriting rich formatting.");
            case ".txt": case ".md": case ".json": case ".xml": case ".yaml": case ".yml": case ".log":
            case ".html": case ".htm": case ".css": case ".js": case ".ts": case ".py": case ".java":
                return result.put("kind", "text").put("text", text(bytes));
            default: throw new Exception("Unsupported format " + extension + ". For legacy DOC, XLS or PPT convert to DOCX, XLSX or PPTX first.");
        }
    }
    private static String rtfToText(String s) {
        s = s.replaceAll("(?s)\\\\fonttbl\\{.*?\\}", "");
        s = s.replace("\\par ", "\n").replace("\\par", "\n").replaceAll("\\\\'[0-9a-fA-F]{2}", "?");
        s = s.replaceAll("\\\\[a-zA-Z]+-?\\d* ?", "");
        return s.replaceAll("[{}]", "").trim();
    }
    private static JSONArray csvAsSheets(String csv) throws Exception {
        JSONArray rows = new JSONArray();
        JSONArray line = new JSONArray(); StringBuilder buf = new StringBuilder(); boolean quoted=false;
        for (int i=0;i<csv.length();i++) {
            char c=csv.charAt(i);
            if(c=='\"') { if (quoted && i+1<csv.length() && csv.charAt(i+1)=='\"') { buf.append('"');i++; } else quoted=!quoted; }
            else if(c==',' && !quoted) { line.put(buf.toString());buf.setLength(0); }
            else if((c=='\n'||c=='\r')&&!quoted) { if (c=='\r'&&i+1<csv.length()&&csv.charAt(i+1)=='\n') i++; line.put(buf.toString());buf.setLength(0);rows.put(line);line=new JSONArray(); }
            else buf.append(c);
        }
        if (buf.length()>0 || line.length()>0) {line.put(buf.toString());rows.put(line);}
        return new JSONArray().put(new JSONObject().put("name", "Sheet 1").put("cells", rows));
    }
    private static JSONArray readXlsx(byte[] data) throws Exception {
        Map<String,byte[]> z = unzip(data);
        if (!z.containsKey("xl/workbook.xml")) throw new Exception("Invalid XLSX");
        List<String> strings = new ArrayList<>();
        if (z.containsKey("xl/sharedStrings.xml")) {
            Document sd=xml(z.get("xl/sharedStrings.xml")); NodeList sis=sd.getElementsByTagNameNS(S,"si");
            for(int i=0;i<sis.getLength();i++) strings.add(nodeText(sis.item(i),S,"t"));
        }
        List<String> names = new ArrayList<>();
        Document wd=xml(z.get("xl/workbook.xml"));NodeList sheets=wd.getElementsByTagNameNS(S,"sheet");
        for(int i=0;i<sheets.getLength();i++)names.add(((Element)sheets.item(i)).getAttribute("name"));
        List<String> paths = new ArrayList<>();
        for(String key:z.keySet()) if(key.matches("xl/worksheets/sheet\\d+\\.xml"))paths.add(key);
        Collections.sort(paths, (a,b)->Integer.compare(sheetNumber(a), sheetNumber(b)));
        JSONArray sheetArray=new JSONArray();
        for(int si=0;si<paths.size();si++) {
            Document sd=xml(z.get(paths.get(si)));
            NodeList cs=sd.getElementsByTagNameNS(S,"c");
            Map<Integer,Map<Integer,String>> values=new HashMap<>();int maxRow=0,maxCol=0;
            for(int i=0;i<cs.getLength();i++) {
                Element c=(Element)cs.item(i);String ref=c.getAttribute("r");
                Matcher m=Pattern.compile("([A-Z]+)([0-9]+)").matcher(ref);if(!m.matches())continue;
                int col=colIndex(m.group(1)), row=Integer.parseInt(m.group(2))-1;
                if(row>499||col>99)continue;
                String val="";NodeList f=c.getElementsByTagNameNS(S,"f");
                if(f.getLength()>0) val="="+f.item(0).getTextContent();
                else if("inlineStr".equals(c.getAttribute("t"))) val=nodeText(c,S,"t");
                else {
                    NodeList vs=c.getElementsByTagNameNS(S,"v");
                    if(vs.getLength()>0) {
                        val=vs.item(0).getTextContent();
                        if("s".equals(c.getAttribute("t"))) {
                            try {val=strings.get(Integer.parseInt(val));}catch(Exception ignored){}
                        }
                    }
                }
                if(!val.isEmpty()){values.computeIfAbsent(row,k->new HashMap<>()).put(col,val);maxRow=Math.max(maxRow,row+1);maxCol=Math.max(maxCol,col+1);}
            }
            JSONArray rows=new JSONArray();
            for(int r=0;r<Math.max(20,maxRow);r++) {
                JSONArray a=new JSONArray();for(int c=0;c<Math.max(8,maxCol);c++) a.put(values.containsKey(r)?values.get(r).getOrDefault(c,""):"");
                rows.put(a);
            }
            sheetArray.put(new JSONObject().put("name",si<names.size()?names.get(si):"Sheet "+(si+1)).put("cells",rows));
        }
        if(sheetArray.length()==0)sheetArray.put(new JSONObject().put("name","Sheet 1").put("cells",new JSONArray()));
        return sheetArray;
    }
    private static int sheetNumber(String s){Matcher m=Pattern.compile("sheet(\\d+)\\.xml").matcher(s);return m.find()?Integer.parseInt(m.group(1)):0;}
    private static int colIndex(String s) {int n=0;for(char c:s.toCharArray())n=n*26+(c-'A'+1);return n-1;}
    private static String colName(int col){StringBuilder b=new StringBuilder();for(col++;col>0;col=(col-1)/26)b.insert(0,(char)('A'+(col-1)%26));return b.toString();}
    private static JSONArray readSlides(byte[] data) throws Exception {
        Map<String,byte[]> z=unzip(data);List<String> paths=new ArrayList<>();
        for(String k:z.keySet())if(k.matches("ppt/slides/slide\\d+\\.xml"))paths.add(k);
        Collections.sort(paths,(a,b)->Integer.compare(slideNumber(a),slideNumber(b)));
        if(paths.isEmpty())throw new Exception("Invalid PPTX");
        JSONArray result=new JSONArray();
        for(String path:paths) {
            Document d=xml(z.get(path)); NodeList sp=d.getElementsByTagNameNS(P,"sp");
            JSONArray items=new JSONArray();
            for(int i=0;i<sp.getLength();i++) {
                String content=nodeText(sp.item(i),A,"t");
                if(!content.isEmpty())items.put(content);
            }
            if(items.length()==0)items.put("");
            result.put(new JSONObject().put("title","Slide "+(result.length()+1)).put("items",items));
        }
        return result;
    }
    private static int slideNumber(String s){Matcher m=Pattern.compile("slide(\\d+)\\.xml").matcher(s);return m.find()?Integer.parseInt(m.group(1)):0;}
    public static byte[] encode(JSONObject obj, String filename, byte[] original, byte[] pptTemplate) throws Exception {
        String extension=ext(filename);
        switch(extension) {
            case ".docx":return writeDocx(obj.optString("html",obj.optString("text","")));
            case ".xlsx":return writeXlsx(obj.optJSONArray("sheets"));
            case ".pptx":return writePptx(obj.optJSONArray("slides"), original, pptTemplate);
            case ".csv":return obj.optJSONArray("sheets") == null ? utf8(obj.optString("text","")) : writeCsv(obj.optJSONArray("sheets"));
            case ".pdf":return writePdf(obj);
            case ".txt":case ".md":case ".json":case ".xml":case ".yaml":case ".yml":case ".log":
            case ".html":case ".htm":
                return utf8(obj.optString("html",obj.optString("text","")));
            case ".css":case ".js":case ".ts":case ".py":case ".java":
                return utf8(obj.optString("text",htmlToPlain(obj.optString("html",""))));
            default:throw new Exception("Saving " + extension + " is not supported. Choose DOCX, XLSX, PPTX, PDF, TXT, CSV or MD.");
        }
    }
    private static String htmlToPlain(String html) {
        return Html.fromHtml(html,Html.FROM_HTML_MODE_LEGACY).toString().trim();
    }
    private static byte[] writeDocx(String html) throws Exception {
        Spanned span=Html.fromHtml(html,Html.FROM_HTML_MODE_LEGACY);
        String body=span.toString();StringBuilder paragraphs=new StringBuilder();
        String[] lines=body.split("\\n",-1);int offset=0;
        for(String line:lines) {
            paragraphs.append("<w:p>");
            int pos=0;
            while(pos<line.length()) {
                int start=offset+pos;int end=offset+line.length();
                int next=span.nextSpanTransition(start,end,Object.class);if(next<=start)next=start+1;
                int localEnd=Math.min(line.length(),next-offset);
                String run=line.substring(pos,localEnd);
                boolean bold=false,italic=false,underline=false;
                for(StyleSpan s:span.getSpans(start,next,StyleSpan.class)) {
                    if((s.getStyle()&Typeface.BOLD)!=0)bold=true;
                    if((s.getStyle()&Typeface.ITALIC)!=0)italic=true;
                }
                underline=span.getSpans(start,next,UnderlineSpan.class).length>0;
                paragraphs.append("<w:r>");
                if(bold||italic||underline) {
                    paragraphs.append("<w:rPr>");if(bold)paragraphs.append("<w:b/>");if(italic)paragraphs.append("<w:i/>");
                    if(underline)paragraphs.append("<w:u w:val=\"single\"/>");paragraphs.append("</w:rPr>");
                }
                paragraphs.append("<w:t xml:space=\"preserve\">").append(esc(run)).append("</w:t></w:r>");
                pos=localEnd;
            }
            paragraphs.append("</w:p>");offset+=line.length()+1;
        }
        String doc="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"+
            "<w:document xmlns:w=\""+W+"\"><w:body>"+paragraphs+"<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>"+
            "<w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr></w:body></w:document>";
        LinkedHashMap<String,byte[]> z=new LinkedHashMap<>();
        z.put("[Content_Types].xml",utf8("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"));
        z.put("_rels/.rels",utf8("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"));
        z.put("word/document.xml",utf8(doc));
        return zip(z);
    }
    private static byte[] writeXlsx(JSONArray sheets) throws Exception {
        if(sheets==null || sheets.length()==0)throw new Exception("No worksheet data");
        LinkedHashMap<String,byte[]> z=new LinkedHashMap<>();StringBuilder work=new StringBuilder(),rels=new StringBuilder(),types=new StringBuilder();
        work.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"").append(S)
            .append("\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        rels.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        types.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
        int count=Math.min(sheets.length(),20);
        for(int i=0;i<count;i++) {
            JSONObject sheet=sheets.optJSONObject(i);if(sheet==null)continue;
            String name=sheet.optString("name","Sheet "+(i+1));
            work.append("<sheet name=\"").append(esc(name.length()>31?name.substring(0,31):name)).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");
            rels.append("<Relationship Id=\"rId").append(i+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i+1).append(".xml\"/>");
            types.append("<Override PartName=\"/xl/worksheets/sheet").append(i+1).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            JSONArray rows=sheet.optJSONArray("cells");StringBuilder content=new StringBuilder();
            content.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"").append(S).append("\"><sheetData>");
            if(rows!=null)for(int r=0;r<Math.min(rows.length(),1000);r++) {
                JSONArray row=rows.optJSONArray(r);if(row==null)continue;
                StringBuilder cells=new StringBuilder();
                for(int c=0;c<Math.min(row.length(),100);c++) {
                    String val=row.optString(c,"");if(val.isEmpty())continue;
                    String ref=colName(c)+(r+1);
                    if(val.startsWith("=")&&val.length()>1) cells.append("<c r=\"").append(ref).append("\"><f>").append(esc(val.substring(1))).append("</f><v>0</v></c>");
                    else if(val.matches("-?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)")) cells.append("<c r=\"").append(ref).append("\"><v>").append(val).append("</v></c>");
                    else cells.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(val)).append("</t></is></c>");
                }
                if(cells.length()>0)content.append("<row r=\"").append(r+1).append("\">").append(cells).append("</row>");
            }
            content.append("</sheetData></worksheet>");
            z.put("xl/worksheets/sheet"+(i+1)+".xml",utf8(content.toString()));
        }
        work.append("</sheets><calcPr fullCalcOnLoad=\"1\"/></workbook>");rels.append("</Relationships>");types.append("</Types>");
        z.put("[Content_Types].xml",utf8(types.toString()));
        z.put("_rels/.rels",utf8("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"));
        z.put("xl/workbook.xml",utf8(work.toString()));z.put("xl/_rels/workbook.xml.rels",utf8(rels.toString()));
        return zip(z);
    }
    private static byte[] writeCsv(JSONArray sheets) {
        StringBuilder out=new StringBuilder();
        if(sheets==null||sheets.length()==0)return new byte[0];
        JSONArray rows=sheets.optJSONObject(0).optJSONArray("cells");
        if(rows!=null)for(int i=0;i<rows.length();i++) {
            JSONArray row=rows.optJSONArray(i);if(row==null)continue;
            int length=row.length();while(length>0&&row.optString(length-1,"").isEmpty())length--;
            for(int j=0;j<length;j++) {
                if(j>0)out.append(',');String val=row.optString(j,"");
                if(val.contains(",")||val.contains("\"")||val.contains("\r")||val.contains("\n")) out.append('"').append(val.replace("\"","\"\"")).append('"');
                else out.append(val);
            }
            if(i<rows.length()-1)out.append("\r\n");
        }
        return utf8(out.toString());
    }
    private static byte[] writePptx(JSONArray slides, byte[] original, byte[] template) throws Exception {
        if(slides==null||slides.length()==0)throw new Exception("No slides");
        // Editing exactly the same number of slides preserves original slide layouts, images and relationships.
        if(original!=null) {
            try {
                LinkedHashMap<String,byte[]> z=unzip(original);
                List<String> paths=new ArrayList<>();
                for(String k:z.keySet())if(k.matches("ppt/slides/slide\\d+\\.xml"))paths.add(k);
                Collections.sort(paths,(a,b)->Integer.compare(slideNumber(a),slideNumber(b)));
                if(paths.size()==slides.length()) {
                    for(int i=0;i<paths.size();i++) {
                        Document d=xml(z.get(paths.get(i)));
                        NodeList shapes=d.getElementsByTagNameNS(P,"sp");
                        JSONArray items=slides.getJSONObject(i).optJSONArray("items");
                        int textBox=0;
                        for(int j=0;j<shapes.getLength();j++) {
                            NodeList txt=((Element)shapes.item(j)).getElementsByTagNameNS(A,"t");
                            if(txt.getLength()==0)continue;
                            String newVal=items!=null&&textBox<items.length()?items.optString(textBox,""):"";
                            txt.item(0).setTextContent(newVal);
                            for(int k=1;k<txt.getLength();k++)txt.item(k).setTextContent("");
                            textBox++;
                        }
                        z.put(paths.get(i),serialize(d));
                    }
                    return zip(z);
                }
            } catch(Exception ignored) { /* fall back to simple presentation */ }
        }
        if(template==null) throw new Exception("Presentation template unavailable");
        LinkedHashMap<String,byte[]> z=unzip(template);
        String base=readStr(z,"ppt/slides/slide1.xml");
        String relationship=readStr(z,"ppt/slides/_rels/slide1.xml.rels");
        String presentation=readStr(z,"ppt/presentation.xml");
        String presentRels=readStr(z,"ppt/_rels/presentation.xml.rels");
        String contentTypes=readStr(z,"[Content_Types].xml");
        for(int i=0;i<slides.length();i++) {
            JSONObject slide=slides.getJSONObject(i);JSONArray items=slide.optJSONArray("items");
            String title=items!=null&&items.length()>0?items.optString(0,""):"Slide "+(i+1);
            StringBuilder body=new StringBuilder();
            if(items!=null)for(int j=1;j<items.length();j++) {if(j>1)body.append("\n");body.append(items.optString(j,""));}
            String slideXml=base.replace("DOCFORGE_TITLE",esc(title)).replace("DOCFORGE_BODY",esc(body.toString()));
            int num=i+1;
            z.put("ppt/slides/slide"+num+".xml",utf8(slideXml));
            if(i>0) {
                if(!relationship.isEmpty())z.put("ppt/slides/_rels/slide"+num+".xml.rels",utf8(relationship));
                String id="rId"+(100+num);
                presentRels=presentRels.replace("</Relationships>","<Relationship Id=\""+id+"\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide"+num+".xml\"/></Relationships>");
                presentation=presentation.replace("</p:sldIdLst>","<p:sldId id=\""+(255+num)+"\" r:id=\""+id+"\"/></p:sldIdLst>");
                contentTypes=contentTypes.replace("</Types>","<Override PartName=\"/ppt/slides/slide"+num+".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/></Types>");
            }
        }
        z.put("ppt/presentation.xml",utf8(presentation));
        z.put("ppt/_rels/presentation.xml.rels",utf8(presentRels));
        z.put("[Content_Types].xml",utf8(contentTypes));
        return zip(z);
    }
    private static byte[] writePdf(JSONObject obj) throws Exception {
        String content=obj.optString("text","");
        if(content.isEmpty())content=htmlToPlain(obj.optString("html",""));
        if(content.isEmpty())content=" ";
        PdfDocument document=new PdfDocument();
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));paint.setTextSize(12);paint.setColor(0xff202532);
        int pageNumber=1, y=48;Canvas canvas=null;PdfDocument.Page currentPage=null;
        try {
            String[] lines=content.replace("\r", "").split("\n",-1);
            for(String line:lines) {
                String rest=line;
                do {
                    String part=rest;
                    if(paint.measureText(part)>505) {
                        int cut=part.length();while(cut>1&&paint.measureText(part.substring(0,cut))>505)cut--;
                        int space=part.lastIndexOf(' ',cut);
                        if(space>cut/2)cut=space;
                        part=part.substring(0,Math.max(1,cut));
                    }
                    if(canvas==null||y>785) {
                        if(canvas!=null)document.finishPage(currentPage);
                        currentPage=document.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNumber++).create());
                        canvas=currentPage.getCanvas();y=48;
                    }
                    canvas.drawText(part,46,y,paint);y+=18;
                    rest=rest.substring(Math.min(rest.length(),part.length())).trim();
                }while(!rest.isEmpty());
            }
            if(canvas!=null)document.finishPage(currentPage);
            else {PdfDocument.Page p=document.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());document.finishPage(p);}
            ByteArrayOutputStream out=new ByteArrayOutputStream();document.writeTo(out);return out.toByteArray();
        } finally {document.close();}
    }
}

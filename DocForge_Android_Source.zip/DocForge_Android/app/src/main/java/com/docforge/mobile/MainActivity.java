package com.docforge.mobile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Android SAF bridge to a 100% bundled, offline HTML editor. */
public class MainActivity extends Activity {
    private static final int OPEN = 31, CREATE = 32;
    private WebView web;
    private Uri selectedUri;
    private String selectedName = "Untitled.txt";
    private byte[] originalBytes, pendingBytes, pptTemplate;
    private String pendingName;
    private boolean loaded = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try { pptTemplate=readAll(getAssets().open("presentation-template.pptx"), 4*1024*1024); }
        catch (Exception ignored) { pptTemplate=null; }
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return !url.startsWith("file:///android_asset/"); }
            @Override public void onPageFinished(WebView v, String url) {
                loaded=true;
                refreshRecents();
                if (getIntent()!=null && Intent.ACTION_VIEW.equals(getIntent().getAction()) && getIntent().getData()!=null) {
                    openUri(getIntent().getData());setIntent(new Intent(MainActivity.this,MainActivity.class));
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private void runJs(String js) { runOnUiThread(() -> { if(loaded)web.evaluateJavascript(js,null); }); }
    private void notifyError(String message) {
        runOnUiThread(() -> {
            Toast.makeText(this,message,Toast.LENGTH_LONG).show();
            if(loaded)web.evaluateJavascript("window.appError("+JSONObject.quote(message)+")",null);
        });
    }
    private static byte[] readAll(InputStream in,int limit) throws Exception {
        try (InputStream stream=in; ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[16384];int n;
            while((n=stream.read(buf))!=-1) {
                out.write(buf,0,n);
                if(out.size()>limit)throw new Exception("File exceeds "+(limit/1024/1024)+" MB size limit");
            }
            return out.toByteArray();
        }
    }
    private String nameOf(Uri uri) {
        String name="Document";
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null&&c.moveToFirst())name=c.getString(0);
        }catch(Exception ignored){}
        return name;
    }
    private void remember(String name,Uri uri) {
        try {
            JSONArray old=new JSONArray(getPreferences(MODE_PRIVATE).getString("recent","[]"));
            JSONArray updated=new JSONArray();
            updated.put(new JSONObject().put("name",name).put("uri",uri.toString()));
            for(int i=0;i<old.length()&&updated.length()<12;i++) {
                JSONObject item=old.optJSONObject(i);
                if(item!=null&&!uri.toString().equals(item.optString("uri")))updated.put(item);
            }
            getPreferences(MODE_PRIVATE).edit().putString("recent",updated.toString()).apply();
            refreshRecents();
        }catch(Exception ignored){}
    }
    private void refreshRecents() {
        String data=getPreferences(MODE_PRIVATE).getString("recent","[]");
        runJs("window.receiveRecents("+JSONObject.quote(data)+")");
    }
    private void openUri(Uri uri) {
        try {
            String name=nameOf(uri);
            if(name.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
                Intent i=new Intent(this,PdfViewerActivity.class);
                i.setData(uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(i);remember(name,uri);
                return;
            }
            byte[] bytes=readAll(getContentResolver().openInputStream(uri),24*1024*1024);
            JSONObject decoded=DocumentCodec.decode(name,bytes);
            selectedUri=uri;selectedName=name;originalBytes=bytes;
            runJs("window.receiveDocument("+JSONObject.quote(decoded.toString())+")");
            remember(name,uri);
        }catch(Exception ex){notifyError("Unable to open: "+ex.getMessage());}
    }
    private String mime(String filename) {
        String n=filename.toLowerCase(Locale.ROOT);
        if(n.endsWith(".docx"))return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if(n.endsWith(".xlsx"))return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if(n.endsWith(".pptx"))return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        if(n.endsWith(".pdf"))return "application/pdf";
        if(n.endsWith(".html")||n.endsWith(".htm"))return "text/html";
        if(n.endsWith(".csv"))return "text/csv";
        if(n.endsWith(".json"))return "application/json";
        if(n.endsWith(".md"))return "text/markdown";
        return "text/plain";
    }
    public final class Bridge {
        @JavascriptInterface public void open() {runOnUiThread(()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i,OPEN);
        });}
        @JavascriptInterface public void openRecent(String uri) {runOnUiThread(()->openUri(Uri.parse(uri)));}
        @JavascriptInterface public void startNew() {runOnUiThread(()->{selectedUri=null;originalBytes=null;selectedName="Untitled.txt";});}
        @JavascriptInterface public void save(String json,String filename,boolean asNew) {runOnUiThread(()->{
            try {
                if(filename.contains("/")||filename.contains("\\"))throw new Exception("Invalid filename");
                byte[] bytes=DocumentCodec.encode(new JSONObject(json),filename,
                        (filename.toLowerCase(Locale.ROOT).endsWith(".pptx") && selectedName.toLowerCase(Locale.ROOT).endsWith(".pptx"))
                            || (!asNew && filename.equals(selectedName)) ? originalBytes : null,pptTemplate);
                if(!asNew && selectedUri!=null && filename.equals(selectedName)) {
                    try(OutputStream out=getContentResolver().openOutputStream(selectedUri,"wt")) {
                        if(out==null)throw new Exception("Cannot open file for writing");out.write(bytes);
                    }
                    originalBytes=bytes;
                    runJs("window.saveCompleted("+JSONObject.quote(filename)+")");remember(filename,selectedUri);
                }else {
                    pendingBytes=bytes;pendingName=filename;
                    Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.setType(mime(filename));i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.putExtra(Intent.EXTRA_TITLE,filename);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(i,CREATE);
                }
            }catch(Exception ex){notifyError("Save failed: "+ex.getMessage());}
        });}
        @JavascriptInterface public String getRecents() {return getPreferences(MODE_PRIVATE).getString("recent","[]");}
        @JavascriptInterface public void message(String message) {notifyError(message);}
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==OPEN) {
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(Exception e){
                try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            }
            openUri(uri);
        }else if(request==CREATE) {
            try {
                if(pendingBytes==null)throw new Exception("Nothing to save");
                try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
                    if(out==null)throw new Exception("Cannot create file");out.write(pendingBytes);
                }
                try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(Exception ignored){}
                selectedUri=uri;selectedName=nameOf(uri);originalBytes=pendingBytes;pendingBytes=null;
                runJs("window.saveCompleted("+JSONObject.quote(selectedName)+")");remember(selectedName,uri);
            }catch(Exception ex){notifyError("Unable to create file: "+ex.getMessage());}
        }
    }
    @Override public void onBackPressed() {
        if(web!=null){web.evaluateJavascript("window.androidBack && window.androidBack()",null);}
        else super.onBackPressed();
    }
}

package com.docforge.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Native offline PDF viewer: page navigation and adjustable zoom. */
public class PdfViewerActivity extends Activity {
    private PdfRenderer renderer;private ParcelFileDescriptor descriptor;
    private int index=0;private float zoom=1.0f;
    private ImageView image;private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            descriptor=getContentResolver().openFileDescriptor(getIntent().getData(),"r");
            renderer=new PdfRenderer(descriptor);
            LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(Color.rgb(241,244,249));
            LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setPadding(7,12,7,12);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(Color.rgb(22,31,53));
            Button back=button("‹ Back",()->finish()),prev=button("◀",()->showPage(index-1)),next=button("▶",()->showPage(index+1));
            Button less=button("−",()->{zoom=Math.max(.7f,zoom-.25f);showPage(index);});
            Button more=button("+",()->{zoom=Math.min(3f,zoom+.25f);showPage(index);});
            status=new TextView(this);status.setTextColor(Color.WHITE);status.setGravity(Gravity.CENTER);status.setTextSize(14);
            bar.addView(back);bar.addView(prev);bar.addView(status,new LinearLayout.LayoutParams(0,-2,1));bar.addView(next);bar.addView(less);bar.addView(more);
            layout.addView(bar);
            ScrollView scroll=new ScrollView(this);image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setAdjustViewBounds(true);image.setBackgroundColor(Color.WHITE);scroll.addView(image);
            layout.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);showPage(0);
        }catch(Exception ex){Toast.makeText(this,"Cannot open PDF: "+ex.getMessage(),Toast.LENGTH_LONG).show();finish();}
    }
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(4,0,4,0);b.setOnClickListener(v->action.run());return b;}
    private void showPage(int target) {
        if(renderer==null||target<0||target>=renderer.getPageCount())return;
        index=target;
        try(PdfRenderer.Page page=renderer.openPage(index)) {
            int width=Math.round(getResources().getDisplayMetrics().widthPixels*zoom);
            width=Math.min(3000,Math.max(400,width));int height=(int)((long)width*page.getHeight()/page.getWidth());
            Bitmap bitmap=Bitmap.createBitmap(width,Math.min(4200,height),Bitmap.Config.ARGB_8888);
            bitmap.eraseColor(Color.WHITE);
            page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            image.setImageBitmap(bitmap);
            status.setText((index+1)+" / "+renderer.getPageCount());
        }catch(Exception e){Toast.makeText(this,"Unable to render page",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onDestroy() {super.onDestroy();try{if(renderer!=null)renderer.close();}catch(Exception ignored){}try{if(descriptor!=null)descriptor.close();}catch(Exception ignored){}}
}

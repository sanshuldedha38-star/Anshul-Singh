'use strict';
let model=null, dirty=false, activeSheet=0, activeSlide=0, recents=[];
const $=id=>document.getElementById(id);
const hasAndroid=typeof window.Android!=='undefined';
const byKind={document:{filename:'Untitled.docx',label:'WORD DOCUMENT',formats:['docx','pdf','txt','md','html']},sheet:{filename:'Untitled.xlsx',label:'SPREADSHEET',formats:['xlsx','csv']},slides:{filename:'Untitled.pptx',label:'PRESENTATION',formats:['pptx']},text:{filename:'Untitled.txt',label:'PLAIN TEXT',formats:['txt','md','json','html','xml','csv','pdf']}};
function escapeHTML(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showToast(message){const t=$('toast');t.textContent=message;t.style.display='block';clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.style.display='none',3300);}
window.appError=showToast;
function markDirty(){dirty=true;$('status').textContent='● Unsaved changes';}
function setClean(){dirty=false;$('status').textContent='✓ Saved';}
function closeModals(){$('newModal').classList.add('hidden');$('saveModal').classList.add('hidden');}
function showNewDialog(){$('newModal').classList.remove('hidden');}
function goHome(){if(dirty && !confirm('You have unsaved changes. Leave the document?'))return;closeModals();$('editorView').classList.add('hidden');$('homeView').classList.remove('hidden');$('bottomNav').classList.remove('hidden');model=null;dirty=false;}
function pickFile(){if(!hasAndroid){showToast('Opening device files requires the Android app.');return;}Android.open();}
function startNew(kind){
 if(model&&dirty&&!confirm('Discard unsaved changes?'))return;
 closeModals();if(hasAndroid)Android.startNew();
 if(kind==='document')model={kind,name:byKind[kind].filename,html:'<h1>Your title</h1><p>Start writing here...</p>'};
 else if(kind==='text')model={kind,name:byKind[kind].filename,text:''};
 else if(kind==='sheet')model={kind,name:byKind[kind].filename,sheets:[{name:'Sheet 1',cells:Array.from({length:20},()=>Array(8).fill(''))}]};
 else if(kind==='slides')model={kind,name:byKind[kind].filename,slides:[{title:'Slide 1',items:['Presentation title','Add your main points here']}]};
 activeSheet=0;activeSlide=0;showEditor();dirty=true;$('status').textContent='● New unsaved document';
}
window.receiveDocument=function(json){try{model=JSON.parse(json);activeSheet=0;activeSlide=0;showEditor();dirty=false;$('status').textContent='File opened';}catch(e){showToast('Could not read document: '+e.message);}};
window.receiveRecents=function(json){try{recents=JSON.parse(json);renderRecents();}catch(e){recents=[];renderRecents();}};
window.saveCompleted=function(filename){if(!model)return;model.name=filename;$('fileName').value=filename;setClean();showToast('Saved: '+filename);};
function renderRecents(){
 $('recentCount').textContent=recents.length+' FILES';
 if(!recents.length){$('recentList').innerHTML='<div class="empty">Open any document to see it here.</div>';return;}
 $('recentList').innerHTML=recents.map((r,i)=>{
 const ext=(r.name.split('.').pop()||'').toLowerCase();const kind=['docx','doc'].includes(ext)?'blue':['xlsx','xls','csv'].includes(ext)?'green':['pptx','ppt'].includes(ext)?'orange':'purple';
 const letter=kind==='blue'?'W':kind==='green'?'X':kind==='orange'?'P':ext==='pdf'?'PDF':'T';
 return `<button class="recent-item" onclick="openRecent(${i})"><div class="file-icon ${kind}">${letter}</div><div><b>${escapeHTML(r.name)}</b><small>${escapeHTML(ext.toUpperCase())} · Tap to open</small></div><span>↗</span></button>`;
 }).join('');
}
function openRecent(i){if(hasAndroid&&recents[i])Android.openRecent(recents[i].uri);}
function showEditor(){
 if(!model)return;
 $('homeView').classList.add('hidden');$('editorView').classList.remove('hidden');$('bottomNav').classList.add('hidden');
 $('fileName').value=model.name;
 $('fileTypeLabel').textContent=(byKind[model.kind]||byKind.text).label;
 for(const id of ['richEditor','textEditor','sheetEditor','slidesEditor','richToolbar'])$(id).classList.add('hidden');
 $('notice').classList.toggle('hidden',!model.notice);
 $('noticeText').textContent=model.notice||'';
 if(model.kind==='document'){
  $('richToolbar').classList.remove('hidden');$('richEditor').classList.remove('hidden');$('richEditor').innerHTML=model.html||'<p></p>';
 }else if(model.kind==='text'){
  $('textEditor').classList.remove('hidden');$('textEditor').value=model.text||'';
 }else if(model.kind==='sheet'){
  $('sheetEditor').classList.remove('hidden');renderSheet();
 }else if(model.kind==='slides'){
  $('slidesEditor').classList.remove('hidden');renderSlides();
 }
}
function format(cmd,val){if(model?.kind!=='document')return;$('richEditor').focus();document.execCommand(cmd,false,val||null);markDirty();}
function snapshot(){
 if(!model)return null;model.name=($('fileName').value||byKind[model.kind].filename).trim();
 if(model.kind==='document')model.html=$('richEditor').innerHTML;
 if(model.kind==='text')model.text=$('textEditor').value;
 // PDF or TXT export uses a textual fallback, while DOCX uses HTML.
 let copy=JSON.parse(JSON.stringify(model));
 if(copy.kind==='document')copy.text=$('richEditor').innerText;
 if(copy.kind==='slides')copy.text=(copy.slides||[]).map(s=>(s.items||[]).join('\n')).join('\n\n');
 if(copy.kind==='sheet')copy.text=(copy.sheets?.[0]?.cells||[]).map(r=>r.join('\t')).join('\n');
 return copy;
}
function save(asNew){
 const payload=snapshot();if(!payload)return;
 if(!hasAndroid){showToast('To save Android files, build and install the APK.');return;}
 if(!payload.name.includes('.')){showToast('Filename must have an extension');return;}
 if(payload.name.toLowerCase().endsWith('.rtf')){showSaveDialog();showToast('Use Save As TXT to avoid overwriting RTF styling');return;}
 Android.save(JSON.stringify(payload),payload.name,!!asNew);
 $('status').textContent='Choose a location if prompted…';
}
function showSaveDialog(){if(!model)return;
 const ext=model.name.includes('.')?model.name.split('.').pop().toLowerCase():'';
 $('exportName').value=model.name.replace(/\.[^.]*$/,'')||'Untitled';
 const formats=(byKind[model.kind]||byKind.text).formats;
 $('exportFormat').innerHTML=formats.map(f=>`<option value="${f}">${f.toUpperCase()}</option>`).join('');
 $('exportFormat').value=formats.includes(ext)?ext:formats[0];
 $('saveModal').classList.remove('hidden');
}
function confirmSaveAs(){
 if(!model)return;
 const basename=$('exportName').value.trim().replace(/\.[^.]*$/,'');
 if(!basename||/[/\\]/.test(basename)){showToast('Enter a valid file name');return;}
 const ext=$('exportFormat').value;
 const p=snapshot();const filename=basename+'.'+ext;
 p.name=filename;
 if(p.kind==='text' && ext==='csv'){} // Plain CSV is passed through without reformatting.
 if(!hasAndroid){showToast('Install the Android app to save to device');return;}
 closeModals();Android.save(JSON.stringify(p),filename,true);$('status').textContent='Choose a location to export…';
}
function colTitle(i){let result='';for(i++;i>0;i=Math.floor((i-1)/26))result=String.fromCharCode(65+(i-1)%26)+result;return result;}
function ensureSheet(){if(!model.sheets?.length)model.sheets=[{name:'Sheet 1',cells:[]}];return model.sheets[activeSheet];}
function renderSheet(){const sheet=ensureSheet();
 const rows=sheet.cells||[];const count=Math.max(20,Math.min(300,rows.length));
 const cols=Math.max(8,Math.min(50,...rows.map(r=>r.length||0)));
 let html='<table><thead><tr><th></th>';
 for(let c=0;c<cols;c++)html+=`<th>${colTitle(c)}</th>`;
 html+='</tr></thead><tbody>';
 for(let r=0;r<count;r++){
  html+=`<tr><th class="row-index">${r+1}</th>`;
  for(let c=0;c<cols;c++){
   const val=rows[r]?.[c]??'';
   html+=`<td><input type="text" data-row="${r}" data-col="${c}" value="${escapeHTML(val)}" aria-label="Cell ${colTitle(c)}${r+1}" onfocus="focusCell(this)" oninput="editCell(this)"></td>`;
  }
  html+='</tr>';
 }
 html+='</tbody></table>';
 $('gridWrap').innerHTML=html;
 $('sheetsBar').innerHTML=model.sheets.map((s,i)=>`<button class="${i===activeSheet?'selected':''}" onclick="switchSheet(${i})">${escapeHTML(s.name)}</button>`).join('')+`<button onclick="addSheet()">＋ Sheet</button><button onclick="addRow()">＋ Row</button><button onclick="addColumn()">＋ Column</button>`;
}
function focusCell(input){$('cellInfo').textContent=colTitle(+input.dataset.col)+(+input.dataset.row+1)+' · '+(input.value||'Empty');}
function editCell(input){const sheet=ensureSheet(),r=+input.dataset.row,c=+input.dataset.col;
 while(sheet.cells.length<=r)sheet.cells.push([]);
 while(sheet.cells[r].length<=c)sheet.cells[r].push('');
 sheet.cells[r][c]=input.value;
 focusCell(input);markDirty();
}
function switchSheet(i){activeSheet=i;renderSheet();}
function addSheet(){if(model.sheets.length>=20){showToast('Maximum 20 sheets');return;}
 model.sheets.push({name:'Sheet '+(model.sheets.length+1),cells:Array.from({length:20},()=>Array(8).fill(''))});activeSheet=model.sheets.length-1;renderSheet();markDirty();}
function addRow(){const s=ensureSheet();if(s.cells.length>=300){showToast('Grid view limit: 300 rows');return;}
 s.cells.push(Array(Math.max(8,s.cells[0]?.length||0)).fill(''));renderSheet();markDirty();}
function addColumn(){const s=ensureSheet();const max=Math.max(8,...s.cells.map(r=>r.length));if(max>=50){showToast('Grid view limit: 50 columns');return;}
 for(const row of s.cells){while(row.length<=max)row.push('');}renderSheet();markDirty();}
function renderSlides(){
 if(!model.slides?.length)model.slides=[{title:'Slide 1',items:['','']}];
 $('slideNav').innerHTML=model.slides.map((s,i)=>`<button class="${activeSlide===i?'selected':''}" onclick="selectSlide(${i})">▣ ${i+1}</button>`).join('')+'<button class="add-slide" onclick="addSlide()">＋ Slide</button>';
 const slide=model.slides[activeSlide];const fields=slide.items||[];
 $('slideCanvas').innerHTML=`<div class="slide-num">SLIDE ${activeSlide+1} OF ${model.slides.length}</div>`+
 fields.map((t,i)=>`<label for="slidebox${i}">${i===0?'SLIDE TITLE':'TEXT BOX '+i}</label><textarea id="slidebox${i}" class="${i===0?'title-field':''}" rows="${i===0?2:4}" oninput="editSlide(${i},this.value)">${escapeHTML(t)}</textarea>`).join('')+
 '<div class="slide-tools"><button onclick="addSlide()">＋ Add slide</button><button class="danger" onclick="deleteSlide()">Delete slide</button></div>';
}
function selectSlide(i){activeSlide=i;renderSlides();}
function editSlide(i,v){model.slides[activeSlide].items[i]=v;markDirty();}
function addSlide(){if(model.slides.length>=30){showToast('Maximum 30 slides');return;}
 model.slides.push({title:'Slide '+(model.slides.length+1),items:['New slide','Add your text here']});activeSlide=model.slides.length-1;renderSlides();markDirty();}
function deleteSlide(){if(model.slides.length<2){showToast('A presentation needs at least one slide');return;}
 model.slides.splice(activeSlide,1);activeSlide=Math.max(0,activeSlide-1);renderSlides();markDirty();}
window.androidBack=function(){if(!$('saveModal').classList.contains('hidden')||!$('newModal').classList.contains('hidden')){closeModals();return;}if(!$('editorView').classList.contains('hidden')){goHome();return;}showToast('You are on the home screen');};
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();save(false);}});
if(hasAndroid){try{window.receiveRecents(Android.getRecents());}catch(e){}}

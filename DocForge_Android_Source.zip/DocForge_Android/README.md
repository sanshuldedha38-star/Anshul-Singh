# DocForge for Android

Offline-first, no-login document editor using a native Android app with a local HTML/JavaScript editing interface and Android's system file picker. All application assets are bundled in the APK; editing requires no web service.

## Supported documents

| Extension | Open | Create / save | Important limitation |
|---|---|---|---|
| .docx | Yes | Yes | Core text and basic bold/italic/underline; complex Word layouts, embedded images, comments and changes are not roundtripped. Save As before changing valuable originals. |
| .xlsx | Yes | Yes | Editable cells and formulas. Complex formatting, charts, pivots, macros not retained on save; current grid display up to 300 rows and 50 columns and exported max 1000x100 cells. |
| .pptx | Yes | Yes | Text-box editing. For same number of slides, saves by replacing existing text in the original package, preserving original media/layout. Adding/deleting slides creates a simplified presentation. |
| .pdf | Yes | Yes (export) | Native paged PDF viewer and simple text-to-PDF export; direct editing/annotation of existing PDF content is NOT supported. |
| .csv | Yes | Yes | Spreadsheet-like table editor, one worksheet per CSV. |
| .txt, .md, .json, .xml, .html, .htm, .css, .js, .ts, .py, .java, .yaml, .yml, .log | Yes | Yes | Plain text editor, no specialized schema/design tools. |
| .rtf | Text extraction only | TXT conversion | Rich formatting not kept. |
| .doc, .xls, .ppt, .odt, .ods, .odp and encrypted/DRM files | No | No | Convert to supported OOXML or text formats elsewhere first. |

**Never advertise as a full Microsoft Office/PDF replacement:** compatibility with advanced features is limited, and opening/re-saving complicated office documents can lose formatting. No auto-save, cloud storage, PDF annotation, or cross-device sync in this version.

## Get an APK without Android Studio: GitHub Actions

1. Create a **private repository** in your GitHub account.
2. Upload the **contents of this folder** (not only the ZIP) to the repository's main branch. Ensure the `.github/workflows/build-apk.yml` file is present.
3. Open the GitHub repository's **Actions** tab and select **Build Android APK**, then **Run workflow**. A push to the main branch can also trigger it.
4. When the workflow finishes successfully, open that run's **Artifacts** section and download **DocForge-debug-APK**.
5. Extract the artifact ZIP to obtain `app-debug.apk`. Transfer it to your Android phone and install it, granting permission to install from that source when prompted. Keep downloads from your own repository only.

The GitHub workflow installs Android SDK platform 35 and Gradle 8.9 with Android Gradle Plugin 8.7.3. GitHub runners need internet access, but the finished app doesn't.

## Android Studio build (alternative)

1. Open this directory as an Android Studio project (JDK 17, Android SDK platform 35).
2. Wait for Gradle sync. Accept SDK component downloads if prompted.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Locate `app/build/outputs/apk/debug/app-debug.apk`.

**Note**: The current deliverable includes source and build automation, not a precompiled APK. This environment has no Android SDK/Gradle and could not run the APK compilation step. The release must be compiled by Android Studio or GitHub Actions.

## Folder overview

- `app/src/main/java/com/docforge/mobile/MainActivity.java` — Android file picker, write access, WebView bridge and recent documents.
- `app/src/main/java/com/docforge/mobile/DocumentCodec.java` — Office Open XML ZIP read/write, CSV/text, and PDF export.
- `app/src/main/java/com/docforge/mobile/PdfViewerActivity.java` — offline native paged PDF viewer.
- `app/src/main/assets/` — responsive local editor and presentation starter template.
- `.github/workflows/build-apk.yml` — APK build automation.

## Privacy and security

No network permission or analytics SDK. Files are opened/saved using Android's Storage Access Framework, so the app does not request broad file-system access. Re-save a copy before testing any complex documents. This is an MVP, not audited for production or sensitive data workflows.
